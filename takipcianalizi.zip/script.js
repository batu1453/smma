// script.js
document.addEventListener("DOMContentLoaded", () => {
    console.log("");
});
